# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: leadyfy.spec.ts >> LEADYFY OS End-to-End Test Suite >> Workflow 1: Authentication & Demo Role Switcher Flow
- Location: e2e/leadyfy.spec.ts:5:7

# Error details

```
Error: browserType.launch: Target page, context or browser has been closed
Browser logs:

<launching> /Applications/Google Chrome.app/Contents/MacOS/Google Chrome --disable-field-trial-config --disable-background-networking --disable-background-timer-throttling --disable-backgrounding-occluded-windows --disable-back-forward-cache --disable-breakpad --disable-client-side-phishing-detection --disable-component-extensions-with-background-pages --disable-component-update --no-default-browser-check --disable-default-apps --disable-dev-shm-usage --disable-edgeupdater --disable-extensions --disable-features=AvoidUnnecessaryBeforeUnloadCheckSync,DestroyProfileOnBrowserClose,DialMediaRouteProvider,GlobalMediaControls,HttpsUpgrades,LensOverlay,MediaRouter,PaintHolding,ThirdPartyStoragePartitioning,BlockOriginHeaderModificationOnRedirect,Translate,AutoDeElevate,OptimizationHints,msForceBrowserSignIn,msEdgeUpdateLaunchServicesPreferredVersion --enable-features=CDPScreenshotNewSurface --allow-pre-commit-input --disable-hang-monitor --disable-ipc-flooding-protection --disable-popup-blocking --disable-prompt-on-repost --disable-renderer-backgrounding --disable-updater-scheduler --force-color-profile=srgb --metrics-recording-only --no-first-run --password-store=basic --use-mock-keychain --no-service-autorun --export-tagged-pdf --disable-search-engine-choice-screen --unsafely-disable-devtools-self-xss-warnings --edge-skip-compat-layer-relaunch --disable-infobars --disable-search-engine-choice-screen --disable-sync --enable-unsafe-swiftshader --headless --hide-scrollbars --mute-audio --blink-settings=primaryHoverType=2,availableHoverTypes=2,primaryPointerType=4,availablePointerTypes=4 --no-sandbox --user-data-dir=/var/folders/w4/0fh2v0vd3qx0336nl41400_h0000gn/T/playwright_chromiumdev_profile-qPpMlB --remote-debugging-pipe --no-startup-window
<launched> pid=61524
[pid=61524][err] [0918/225119.874863:ERROR:third_party/crashpad/crashpad/util/mach/bootstrap.cc:65] bootstrap_check_in org.chromium.crashpad.child_port_handshake.61526.913842.VDVYVDMGPCQOBDFD: Permission denied (1100)
[pid=61524][err] [0918/225119.875512:ERROR:third_party/crashpad/crashpad/util/file/file_io.cc:103] ReadExactly: expected 4, observed 0
[pid=61524][err] [0918/225119.876458:ERROR:third_party/crashpad/crashpad/util/file/file_io_posix.cc:208] open /Users/admin/Library/Application Support/Google/Chrome/Crashpad/settings.dat: Operation not permitted (1)
[pid=61524][err] [0918/225119.876557:ERROR:third_party/crashpad/crashpad/util/file/file_io_posix.cc:208] open /Users/admin/Library/Application Support/Google/Chrome/Crashpad/settings.dat: Operation not permitted (1)
[pid=61524][err] [61524:913879:0918/225120.070816:FATAL:base/apple/mach_port_rendezvous_mac.cc:159] Check failed: kr == KERN_SUCCESS. bootstrap_check_in com.google.Chrome.MachPortRendezvousServer.61524: Permission denied (1100)
Call log:
  - <launching> /Applications/Google Chrome.app/Contents/MacOS/Google Chrome --disable-field-trial-config --disable-background-networking --disable-background-timer-throttling --disable-backgrounding-occluded-windows --disable-back-forward-cache --disable-breakpad --disable-client-side-phishing-detection --disable-component-extensions-with-background-pages --disable-component-update --no-default-browser-check --disable-default-apps --disable-dev-shm-usage --disable-edgeupdater --disable-extensions --disable-features=AvoidUnnecessaryBeforeUnloadCheckSync,DestroyProfileOnBrowserClose,DialMediaRouteProvider,GlobalMediaControls,HttpsUpgrades,LensOverlay,MediaRouter,PaintHolding,ThirdPartyStoragePartitioning,BlockOriginHeaderModificationOnRedirect,Translate,AutoDeElevate,OptimizationHints,msForceBrowserSignIn,msEdgeUpdateLaunchServicesPreferredVersion --enable-features=CDPScreenshotNewSurface --allow-pre-commit-input --disable-hang-monitor --disable-ipc-flooding-protection --disable-popup-blocking --disable-prompt-on-repost --disable-renderer-backgrounding --disable-updater-scheduler --force-color-profile=srgb --metrics-recording-only --no-first-run --password-store=basic --use-mock-keychain --no-service-autorun --export-tagged-pdf --disable-search-engine-choice-screen --unsafely-disable-devtools-self-xss-warnings --edge-skip-compat-layer-relaunch --disable-infobars --disable-search-engine-choice-screen --disable-sync --enable-unsafe-swiftshader --headless --hide-scrollbars --mute-audio --blink-settings=primaryHoverType=2,availableHoverTypes=2,primaryPointerType=4,availablePointerTypes=4 --no-sandbox --user-data-dir=/var/folders/w4/0fh2v0vd3qx0336nl41400_h0000gn/T/playwright_chromiumdev_profile-qPpMlB --remote-debugging-pipe --no-startup-window
  - <launched> pid=61524
  - [pid=61524][err] [0918/225119.874863:ERROR:third_party/crashpad/crashpad/util/mach/bootstrap.cc:65] bootstrap_check_in org.chromium.crashpad.child_port_handshake.61526.913842.VDVYVDMGPCQOBDFD: Permission denied (1100)
  - [pid=61524][err] [0918/225119.875512:ERROR:third_party/crashpad/crashpad/util/file/file_io.cc:103] ReadExactly: expected 4, observed 0
  - [pid=61524][err] [0918/225119.876458:ERROR:third_party/crashpad/crashpad/util/file/file_io_posix.cc:208] open /Users/admin/Library/Application Support/Google/Chrome/Crashpad/settings.dat: Operation not permitted (1)
  - [pid=61524][err] [0918/225119.876557:ERROR:third_party/crashpad/crashpad/util/file/file_io_posix.cc:208] open /Users/admin/Library/Application Support/Google/Chrome/Crashpad/settings.dat: Operation not permitted (1)
  - [pid=61524][err] [61524:913879:0918/225120.070816:FATAL:base/apple/mach_port_rendezvous_mac.cc:159] Check failed: kr == KERN_SUCCESS. bootstrap_check_in com.google.Chrome.MachPortRendezvousServer.61524: Permission denied (1100)
  - [pid=61524] <gracefully close start>
  - [pid=61524] <kill>
  - [pid=61524] <will force kill>
  - [pid=61524] exception while trying to kill process: Error: kill EPERM
  - [pid=61524] <process did exit: exitCode=null, signal=SIGTRAP>
  - [pid=61524] starting temporary directories cleanup
  - [pid=61524] finished temporary directories cleanup
  - [pid=61524] <gracefully close end>

```