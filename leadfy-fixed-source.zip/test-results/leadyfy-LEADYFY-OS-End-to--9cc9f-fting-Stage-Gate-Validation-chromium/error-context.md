# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: leadyfy.spec.ts >> LEADYFY OS End-to-End Test Suite >> Workflow 6: Script Drafting & Stage Gate Validation
- Location: e2e/leadyfy.spec.ts:111:7

# Error details

```
AggregateError: apiRequestContext.post: connect EPERM ::1:3000 - Local (:::0)
connect EPERM 127.0.0.1:3000 - Local (0.0.0.0:0)
Call log:
  - → POST http://localhost:3000/api/auth/login
    - user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.8010.12 Safari/537.36
    - accept: */*
    - accept-encoding: gzip,deflate,br
    - content-type: application/json
    - content-length: 54

```

# Test source

```ts
  12  |     await expect(demoSwitcher).toBeVisible();
  13  | 
  14  |     // Fill credentials for Owner
  15  |     await page.fill('input[type="email"]', 'owner@leadyfy.com');
  16  |     await page.fill('input[type="password"]', 'leadyfy123');
  17  |     await page.click('button[type="submit"]');
  18  | 
  19  |     // Wait for redirect to dashboard
  20  |     await page.waitForURL('**/dashboard');
  21  |     await expect(page.locator('text=Agency Command Center')).toBeVisible();
  22  |   });
  23  | 
  24  |   test('Workflow 2: RBAC Access Control & Route Guards', async ({ page }) => {
  25  |     // Login as Video Editor
  26  |     await page.goto('/login');
  27  |     await page.click('button:has-text("Editor")');
  28  |     await page.waitForURL('**/dashboard/editor');
  29  | 
  30  |     // Editor should not have access to financial reports or payouts
  31  |     await page.goto('/dashboard/payouts');
  32  |     // Guard redirects to /dashboard/editor or displays 403 Forbidden
  33  |     const currentUrl = page.url();
  34  |     const hasForbidden = await page.locator('text=Access Denied').or(page.locator('text=Forbidden')).isVisible().catch(() => false);
  35  |     const wasRedirected = currentUrl.includes('/dashboard/editor') || currentUrl.includes('/dashboard');
  36  |     expect(wasRedirected || hasForbidden).toBeTruthy();
  37  |   });
  38  | 
  39  |   test('Workflow 3: Canonical Company Name Flow (company vs company_name)', async ({ request }) => {
  40  |     // Authenticate as Admin via API
  41  |     const loginRes = await request.post('/api/auth/login', {
  42  |       data: { email: 'admin@leadyfy.com', password: 'password123' },
  43  |     });
  44  |     expect(loginRes.ok()).toBeTruthy();
  45  |     const cookies = loginRes.headers()['set-cookie'];
  46  | 
  47  |     // Create client using legacy payload key "company"
  48  |     const createRes = await request.post('/api/clients', {
  49  |       headers: { cookie: cookies || '' },
  50  |       data: {
  51  |         company: 'Playwright Test Brand Inc',
  52  |         brandName: 'Playwright Brand',
  53  |         contactName: 'Playwright Tester',
  54  |         email: `pw_${Date.now()}@brand.com`,
  55  |         phone: '+15559876543',
  56  |         industry: 'E-commerce',
  57  |         status: 'ACTIVE',
  58  |       },
  59  |     });
  60  |     expect(createRes.status()).toBe(201);
  61  |     const created = await createRes.json();
  62  |     expect(created.client.companyName).toBe('Playwright Test Brand Inc');
  63  |     expect(created.client.company).toBe('Playwright Test Brand Inc');
  64  |   });
  65  | 
  66  |   test('Workflow 4: Client Multi-Tenant Isolation Guard', async ({ request }) => {
  67  |     // Login as Client A
  68  |     const clientALogin = await request.post('/api/auth/login', {
  69  |       data: { email: 'client@glowbotanics.com', password: 'password123' },
  70  |     });
  71  |     expect(clientALogin.ok()).toBeTruthy();
  72  |     const cookiesA = clientALogin.headers()['set-cookie'];
  73  | 
  74  |     // Client A requests /portal data
  75  |     const portalRes = await request.get('/api/orders', {
  76  |       headers: { cookie: cookiesA || '' },
  77  |     });
  78  |     expect(portalRes.ok()).toBeTruthy();
  79  |     const orders = await portalRes.json();
  80  |     
  81  |     // Client A should only see their own orders
  82  |     for (const order of orders.orders || []) {
  83  |       expect(order.client.contactEmail).toBe('client@glowbotanics.com');
  84  |     }
  85  |   });
  86  | 
  87  |   test('Workflow 5: Order Lifecycle & Production Counter Engine', async ({ request }) => {
  88  |     const loginRes = await request.post('/api/auth/login', {
  89  |       data: { email: 'owner@leadyfy.com', password: 'password123' },
  90  |     });
  91  |     const cookies = loginRes.headers()['set-cookie'];
  92  | 
  93  |     // Create new order
  94  |     const orderRes = await request.post('/api/orders', {
  95  |       headers: { cookie: cookies || '' },
  96  |       data: {
  97  |         clientId: 'client-1',
  98  |         packageType: 'STANDARD_BATCH',
  99  |         videoCount: 4,
  100 |         totalAmount: 3200,
  101 |         currency: 'USD',
  102 |         notes: 'Playwright E2E Order',
  103 |       },
  104 |     });
  105 |     expect(orderRes.status()).toBe(201);
  106 |     const orderData = await orderRes.json();
  107 |     expect(orderData.order.videoCount).toBe(4);
  108 |     expect(orderData.order.status).toBe('ONBOARDING');
  109 |   });
  110 | 
  111 |   test('Workflow 6: Script Drafting & Stage Gate Validation', async ({ request }) => {
> 112 |     const loginRes = await request.post('/api/auth/login', {
      |                                    ^ AggregateError: apiRequestContext.post: connect EPERM ::1:3000 - Local (:::0)
  113 |       data: { email: 'owner@leadyfy.com', password: 'password123' },
  114 |     });
  115 |     const cookies = loginRes.headers()['set-cookie'];
  116 | 
  117 |     // Create script in DRAFT
  118 |     const scriptRes = await request.post('/api/scripts', {
  119 |       headers: { cookie: cookies || '' },
  120 |       data: {
  121 |         orderId: 'order-1',
  122 |         title: 'PW Script Hook Concept',
  123 |         hook: 'Stop scrolling if you need better skin!',
  124 |         body: 'Here is why this botanical serum actually works...',
  125 |         cta: 'Click link below for 20% off',
  126 |       },
  127 |     });
  128 |     expect(scriptRes.status()).toBe(201);
  129 |     const script = (await scriptRes.json()).script;
  130 | 
  131 |     // Strict Rule: Cannot jump from DRAFT directly to READY_FOR_SHOOT
  132 |     const invalidJump = await request.patch(`/api/scripts/${script.id}`, {
  133 |       headers: { cookie: cookies || '' },
  134 |       data: { status: 'READY_FOR_SHOOT' },
  135 |     });
  136 |     expect(invalidJump.status()).toBe(400);
  137 | 
  138 |     // Valid flow: DRAFT -> IN_REVIEW -> APPROVED -> READY_FOR_SHOOT
  139 |     await request.patch(`/api/scripts/${script.id}`, {
  140 |       headers: { cookie: cookies || '' },
  141 |       data: { status: 'IN_REVIEW' },
  142 |     });
  143 |     await request.patch(`/api/scripts/${script.id}`, {
  144 |       headers: { cookie: cookies || '' },
  145 |       data: { status: 'APPROVED' },
  146 |     });
  147 |     const readyRes = await request.patch(`/api/scripts/${script.id}`, {
  148 |       headers: { cookie: cookies || '' },
  149 |       data: { status: 'READY_FOR_SHOOT' },
  150 |     });
  151 |     expect(readyRes.status()).toBe(200);
  152 |   });
  153 | 
  154 |   test('Workflow 7: Creator Double-Booking Conflict Prevention', async ({ request }) => {
  155 |     const loginRes = await request.post('/api/auth/login', {
  156 |       data: { email: 'owner@leadyfy.com', password: 'password123' },
  157 |     });
  158 |     const cookies = loginRes.headers()['set-cookie'];
  159 | 
  160 |     const shootDate = new Date(Date.now() + 86400000 * 5).toISOString();
  161 | 
  162 |     // Schedule first shoot
  163 |     const shoot1 = await request.post('/api/shoots', {
  164 |       headers: { cookie: cookies || '' },
  165 |       data: {
  166 |         orderId: 'order-1',
  167 |         creatorId: 'creator-1',
  168 |         scheduledDate: shootDate,
  169 |         location: 'Studio Loft A',
  170 |         status: 'SCHEDULED',
  171 |       },
  172 |     });
  173 |     expect(shoot1.status()).toBe(201);
  174 | 
  175 |     // Attempt to schedule overlapping shoot for same creator on same date
  176 |     const shoot2 = await request.post('/api/shoots', {
  177 |       headers: { cookie: cookies || '' },
  178 |       data: {
  179 |         orderId: 'order-1',
  180 |         creatorId: 'creator-1',
  181 |         scheduledDate: shootDate,
  182 |         location: 'Studio Loft B',
  183 |         status: 'SCHEDULED',
  184 |       },
  185 |     });
  186 |     // Double-booking must be strictly rejected with HTTP 409 Conflict
  187 |     expect(shoot2.status()).toBe(409);
  188 |   });
  189 | 
  190 |   test('Workflow 8: Shoot Schedule & Checklists Management', async ({ request }) => {
  191 |     const loginRes = await request.post('/api/auth/login', {
  192 |       data: { email: 'owner@leadyfy.com', password: 'password123' },
  193 |     });
  194 |     const cookies = loginRes.headers()['set-cookie'];
  195 | 
  196 |     const shootList = await request.get('/api/shoots', {
  197 |       headers: { cookie: cookies || '' },
  198 |     });
  199 |     expect(shootList.ok()).toBeTruthy();
  200 |     const shoots = await shootList.json();
  201 |     expect(shoots.shoots.length).toBeGreaterThan(0);
  202 |   });
  203 | 
  204 |   test('Workflow 9: Linear 9-Stage Video Production Pipeline', async ({ request }) => {
  205 |     const loginRes = await request.post('/api/auth/login', {
  206 |       data: { email: 'owner@leadyfy.com', password: 'password123' },
  207 |     });
  208 |     const cookies = loginRes.headers()['set-cookie'];
  209 | 
  210 |     const videoRes = await request.post('/api/videos', {
  211 |       headers: { cookie: cookies || '' },
  212 |       data: {
```