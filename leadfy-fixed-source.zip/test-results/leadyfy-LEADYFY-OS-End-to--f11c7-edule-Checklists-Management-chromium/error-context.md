# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: leadyfy.spec.ts >> LEADYFY OS End-to-End Test Suite >> Workflow 8: Shoot Schedule & Checklists Management
- Location: e2e/leadyfy.spec.ts:190:7

# Error details

```
AggregateError: apiRequestContext.post: connect EPERM ::1:3000 - Local (:::0)
connect EPERM 127.0.0.1:3000 - Local (0.0.0.0:0)
Call log:
  - → POST http://localhost:3000/api/auth/login
    - user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.8010.12 Safari/537.36
    - accept: */*
    - accept-encoding: gzip,deflate,br
    - content-type: application/json
    - content-length: 54

```

# Test source

```ts
  91  |     const cookies = loginRes.headers()['set-cookie'];
  92  | 
  93  |     // Create new order
  94  |     const orderRes = await request.post('/api/orders', {
  95  |       headers: { cookie: cookies || '' },
  96  |       data: {
  97  |         clientId: 'client-1',
  98  |         packageType: 'STANDARD_BATCH',
  99  |         videoCount: 4,
  100 |         totalAmount: 3200,
  101 |         currency: 'USD',
  102 |         notes: 'Playwright E2E Order',
  103 |       },
  104 |     });
  105 |     expect(orderRes.status()).toBe(201);
  106 |     const orderData = await orderRes.json();
  107 |     expect(orderData.order.videoCount).toBe(4);
  108 |     expect(orderData.order.status).toBe('ONBOARDING');
  109 |   });
  110 | 
  111 |   test('Workflow 6: Script Drafting & Stage Gate Validation', async ({ request }) => {
  112 |     const loginRes = await request.post('/api/auth/login', {
  113 |       data: { email: 'owner@leadyfy.com', password: 'password123' },
  114 |     });
  115 |     const cookies = loginRes.headers()['set-cookie'];
  116 | 
  117 |     // Create script in DRAFT
  118 |     const scriptRes = await request.post('/api/scripts', {
  119 |       headers: { cookie: cookies || '' },
  120 |       data: {
  121 |         orderId: 'order-1',
  122 |         title: 'PW Script Hook Concept',
  123 |         hook: 'Stop scrolling if you need better skin!',
  124 |         body: 'Here is why this botanical serum actually works...',
  125 |         cta: 'Click link below for 20% off',
  126 |       },
  127 |     });
  128 |     expect(scriptRes.status()).toBe(201);
  129 |     const script = (await scriptRes.json()).script;
  130 | 
  131 |     // Strict Rule: Cannot jump from DRAFT directly to READY_FOR_SHOOT
  132 |     const invalidJump = await request.patch(`/api/scripts/${script.id}`, {
  133 |       headers: { cookie: cookies || '' },
  134 |       data: { status: 'READY_FOR_SHOOT' },
  135 |     });
  136 |     expect(invalidJump.status()).toBe(400);
  137 | 
  138 |     // Valid flow: DRAFT -> IN_REVIEW -> APPROVED -> READY_FOR_SHOOT
  139 |     await request.patch(`/api/scripts/${script.id}`, {
  140 |       headers: { cookie: cookies || '' },
  141 |       data: { status: 'IN_REVIEW' },
  142 |     });
  143 |     await request.patch(`/api/scripts/${script.id}`, {
  144 |       headers: { cookie: cookies || '' },
  145 |       data: { status: 'APPROVED' },
  146 |     });
  147 |     const readyRes = await request.patch(`/api/scripts/${script.id}`, {
  148 |       headers: { cookie: cookies || '' },
  149 |       data: { status: 'READY_FOR_SHOOT' },
  150 |     });
  151 |     expect(readyRes.status()).toBe(200);
  152 |   });
  153 | 
  154 |   test('Workflow 7: Creator Double-Booking Conflict Prevention', async ({ request }) => {
  155 |     const loginRes = await request.post('/api/auth/login', {
  156 |       data: { email: 'owner@leadyfy.com', password: 'password123' },
  157 |     });
  158 |     const cookies = loginRes.headers()['set-cookie'];
  159 | 
  160 |     const shootDate = new Date(Date.now() + 86400000 * 5).toISOString();
  161 | 
  162 |     // Schedule first shoot
  163 |     const shoot1 = await request.post('/api/shoots', {
  164 |       headers: { cookie: cookies || '' },
  165 |       data: {
  166 |         orderId: 'order-1',
  167 |         creatorId: 'creator-1',
  168 |         scheduledDate: shootDate,
  169 |         location: 'Studio Loft A',
  170 |         status: 'SCHEDULED',
  171 |       },
  172 |     });
  173 |     expect(shoot1.status()).toBe(201);
  174 | 
  175 |     // Attempt to schedule overlapping shoot for same creator on same date
  176 |     const shoot2 = await request.post('/api/shoots', {
  177 |       headers: { cookie: cookies || '' },
  178 |       data: {
  179 |         orderId: 'order-1',
  180 |         creatorId: 'creator-1',
  181 |         scheduledDate: shootDate,
  182 |         location: 'Studio Loft B',
  183 |         status: 'SCHEDULED',
  184 |       },
  185 |     });
  186 |     // Double-booking must be strictly rejected with HTTP 409 Conflict
  187 |     expect(shoot2.status()).toBe(409);
  188 |   });
  189 | 
  190 |   test('Workflow 8: Shoot Schedule & Checklists Management', async ({ request }) => {
> 191 |     const loginRes = await request.post('/api/auth/login', {
      |                                    ^ AggregateError: apiRequestContext.post: connect EPERM ::1:3000 - Local (:::0)
  192 |       data: { email: 'owner@leadyfy.com', password: 'password123' },
  193 |     });
  194 |     const cookies = loginRes.headers()['set-cookie'];
  195 | 
  196 |     const shootList = await request.get('/api/shoots', {
  197 |       headers: { cookie: cookies || '' },
  198 |     });
  199 |     expect(shootList.ok()).toBeTruthy();
  200 |     const shoots = await shootList.json();
  201 |     expect(shoots.shoots.length).toBeGreaterThan(0);
  202 |   });
  203 | 
  204 |   test('Workflow 9: Linear 9-Stage Video Production Pipeline', async ({ request }) => {
  205 |     const loginRes = await request.post('/api/auth/login', {
  206 |       data: { email: 'owner@leadyfy.com', password: 'password123' },
  207 |     });
  208 |     const cookies = loginRes.headers()['set-cookie'];
  209 | 
  210 |     const videoRes = await request.post('/api/videos', {
  211 |       headers: { cookie: cookies || '' },
  212 |       data: {
  213 |         orderId: 'order-1',
  214 |         title: 'PW Pipeline Video',
  215 |         aspectRatio: '9:16',
  216 |         version: 1,
  217 |         editorId: 'emp-editor',
  218 |       },
  219 |     });
  220 |     expect(videoRes.status()).toBe(201);
  221 |     const video = (await videoRes.json()).video;
  222 | 
  223 |     // Advance through pipeline: RAW_FOOTAGE_RECEIVED -> EDITING_IN_PROGRESS -> INTERNAL_REVIEW
  224 |     const editRes = await request.patch(`/api/videos/${video.id}`, {
  225 |       headers: { cookie: cookies || '' },
  226 |       data: { status: 'EDITING_IN_PROGRESS' },
  227 |     });
  228 |     expect(editRes.status()).toBe(200);
  229 | 
  230 |     // Illegal jump: Cannot jump directly to DELIVERED without FINAL_APPROVED
  231 |     const jumpRes = await request.patch(`/api/videos/${video.id}`, {
  232 |       headers: { cookie: cookies || '' },
  233 |       data: { status: 'DELIVERED' },
  234 |     });
  235 |     expect(jumpRes.status()).toBe(400);
  236 |   });
  237 | 
  238 |   test('Workflow 10: Client Video Review & Timestamped Revision Flow', async ({ request }) => {
  239 |     // Client submits revision note with timestamp
  240 |     const clientLogin = await request.post('/api/auth/login', {
  241 |       data: { email: 'client@glowbotanics.com', password: 'password123' },
  242 |     });
  243 |     const cookies = clientLogin.headers()['set-cookie'];
  244 | 
  245 |     const feedbackRes = await request.post('/api/videos/video-1/feedback', {
  246 |       headers: { cookie: cookies || '' },
  247 |       data: {
  248 |         action: 'REVISION',
  249 |         comment: 'Please shorten the intro hook at 0:03 and brighten the product shot.',
  250 |         timestampSeconds: 3.5,
  251 |       },
  252 |     });
  253 |     expect(feedbackRes.status()).toBe(200);
  254 |     const resData = await feedbackRes.json();
  255 |     expect(resData.video.status).toBe('REVISION');
  256 |     expect(resData.video.revisionCount).toBeGreaterThanOrEqual(1);
  257 |   });
  258 | 
  259 |   test('Workflow 11: Final Approval & Secure Delivery Asset Link', async ({ request }) => {
  260 |     // Admin approves final video
  261 |     const adminLogin = await request.post('/api/auth/login', {
  262 |       data: { email: 'admin@leadyfy.com', password: 'password123' },
  263 |     });
  264 |     const adminCookies = adminLogin.headers()['set-cookie'];
  265 | 
  266 |     const approveRes = await request.post('/api/videos/video-1/approve', {
  267 |       headers: { cookie: adminCookies || '' },
  268 |       data: {
  269 |         deliveryLink: 'https://cdn.leadyfy.com/deliveries/final-glow-botanics-ad1.mp4',
  270 |       },
  271 |     });
  272 |     expect(approveRes.status()).toBe(200);
  273 |     const resData = await approveRes.json();
  274 |     expect(resData.video.status).toBe('FINAL_APPROVED');
  275 |     expect(resData.video.deliveryLink).toBe('https://cdn.leadyfy.com/deliveries/final-glow-botanics-ad1.mp4');
  276 |   });
  277 | 
  278 |   test('Workflow 12: Financial Engine & Duplicate Creator Payout Guard', async ({ request }) => {
  279 |     const ownerLogin = await request.post('/api/auth/login', {
  280 |       data: { email: 'owner@leadyfy.com', password: 'password123' },
  281 |     });
  282 |     const ownerCookies = ownerLogin.headers()['set-cookie'];
  283 | 
  284 |     // Fetch Profit Summary
  285 |     const profitRes = await request.get('/api/finances/profit', {
  286 |       headers: { ownerCookies: ownerCookies || '' },
  287 |     });
  288 |     expect(profitRes.ok()).toBeTruthy();
  289 |     const profit = await profitRes.json();
  290 |     expect(profit.netProfit).toBeDefined();
  291 |     expect(profit.profitMarginPct).toBeDefined();
```